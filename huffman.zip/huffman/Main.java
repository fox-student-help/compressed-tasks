package huffman;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        HuffManDriver driver = new HuffManDriver();
        driver.encode("src/main/resources/bigData.txt", "src/main/resources/output.txt");
        driver.decode("src/main/resources/output.txt", "src/main/resources/output2.txt");
    }
}
