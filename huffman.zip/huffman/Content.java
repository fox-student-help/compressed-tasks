package huffman;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;

public class Content {
    private final byte[] data;
    private final byte[] tree;
    private final byte[] chars;
    private byte[] all;
    private final byte END_OF_PACKET = '\n';
    BitConverter bitConverter = new BitConverter();

    public Content(byte[] data, byte[] tree, byte[] chars) {
        this.data = data;
        this.tree = tree;
        this.chars = chars;
    }

    public byte[] getData() {
        return data;
    }

    public byte[] getTree() {
        return tree;
    }

    public byte[] getChars() {
        return chars;
    }


    /**
     * @return an array of type byte which contains the compressed data and tree and chars separated by END_OF_PACKET
     */
    public byte[] getBytes() {
        return compose();
    }


    private byte[] compose() {
        if (all != null) {
            return all;
        }
        byte[] compressedData = bitConverter.compressBits(data);
        byte[] compressedTree = bitConverter.compressBits(tree);
        int top = 0;
        int size = compressedData.length + 1 + compressedTree.length + 1 + chars.length;
        all = new byte[size];

        System.arraycopy(compressedData, 0, all, top, compressedData.length);
        top += compressedData.length;
        all[top] = END_OF_PACKET;
        top++;

        System.arraycopy(compressedTree, 0, all, top, compressedTree.length);
        top += compressedTree.length;
        all[top] = END_OF_PACKET;
        top++;

        System.arraycopy(chars, 0, all, top, chars.length);
        return all;
    }

    @Override
    public int hashCode() {
        int hashcode = 13;
        hashcode += 11 * Arrays.hashCode(tree);
        hashcode += 7 * Arrays.hashCode(chars);
        hashcode *= 1e9 + 7;
        hashcode += 5 * Arrays.hashCode(data);
        return hashcode;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Content)) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        Content content = (Content) obj;

        return Arrays.equals(content.data, data) &&
                Arrays.equals(content.tree, tree) &&
                Arrays.equals(content.chars, chars);
    }

    public int getDataLength() {
        return data.length;
    }

    public int getTreeLength() {
        return tree.length;
    }

    public int getCharsLength() {
        return chars.length;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        byte[] bytes = getBytes();
        sb.append(bytes.length);
        sb.append("\n");
        sb.append(getDataLength());
        sb.append("\n");
        sb.append(getTreeLength());
        sb.append("\n");
        sb.append(getCharsLength());
        sb.append("\n");
        sb.append(new String(bytes, StandardCharsets.UTF_8));
        return sb.toString();
    }
}