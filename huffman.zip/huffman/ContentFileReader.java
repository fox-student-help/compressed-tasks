package huffman;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

class ContentFileReader {
    /**
     * Reads the file and returns a content instance
     *
     * @param uri path to the file
     * @return content instance
     * @throws IOException if file is corrupted
     */
    public Content read(String uri) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(uri))) {
            List<String> lines = getLines(reader);
            byte[] dataBits = getBits(lines, 4, 1);
            byte[] treeBits = getBits(lines, 5, 2);
            byte[] chars = getChars(lines);
            checkIsFileCorrupted(lines);
            return new Content(dataBits, treeBits, chars);
        }
    }

    private List<String> getLines(BufferedReader reader) throws IOException {
        String line;
        List<String> lines = new ArrayList<>();
        while ((line = reader.readLine()) != null) {
            lines.add(line);
        }
        return lines;
    }

    private byte[] getChars(List<String> lines) {
        int index = 6;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(lines.get(index));
        index++;
        while (index < lines.size()) {
            stringBuilder.append('\n');
            stringBuilder.append(lines.get(index));
            index++;
        }
        String charsString = stringBuilder.toString();
        return charsString.getBytes(StandardCharsets.UTF_8);
    }

    // checks if the size of data is correct
    private void checkIsFileCorrupted(List<String> lines) throws IOException {
        int allBytes = Integer.parseInt(lines.get(0));
        int allBytesLength = getBytes(lines, 4).length +
                getBytes(lines, 5).length +
                getChars(lines).length;
        int numberOfBreakLines = 2;
        allBytesLength = allBytesLength + numberOfBreakLines;
        if (allBytesLength != allBytes) {
            throw new IOException("File is corrupted");
        }
    }

    private byte[] getBytes(List<String> lines, int i) {
        return lines.get(i).getBytes(StandardCharsets.UTF_8);
    }

    private byte[] getBits(List<String> lines, int index, int sizeIndex) {
        int size = Integer.parseInt(lines.get(sizeIndex));
        BitConverter bitConverter = new BitConverter();
        String string = lines.get(index);
        byte[] bytes = string.getBytes(StandardCharsets.UTF_8);
        return bitConverter.unCompressBits(bytes, size);
    }
}
