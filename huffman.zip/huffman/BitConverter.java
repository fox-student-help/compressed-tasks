package huffman;

class BitConverter {
    private final double BITS_IN_BYTE = 7.0;
    private final int CARRIAGE_RETURN = 13;
    private final int LINE_FEED = 10;
    private final int REPLACEMENT_LINE = Byte.MAX_VALUE;
    private final int REPLACEMENT_CARRIAGE = Byte.MAX_VALUE - 1;

    /**
     * Compresses the bits into bytes
     * @param bits an array of type byte which contains the bits in bytes where each byte contains only one bit
     * @return an array of type byte which contains the bits in bytes
     */
    byte[] compressBits(byte[] bits) {
        int length = bits.length;
        int numberOfBytes = (int) Math.ceil(length / BITS_IN_BYTE);
        byte[] bytes = new byte[numberOfBytes];
        int index = 0;
        int byteIndex = 0;
        while (index < length) {
            byte b = getByte(bits, length, index);
            if(b == LINE_FEED) {
                b = REPLACEMENT_LINE;
            }
            if(b == CARRIAGE_RETURN) {
                b = REPLACEMENT_CARRIAGE;
            }
            index += BITS_IN_BYTE;
            bytes[byteIndex] = b;
            byteIndex++;
        }
        return bytes;
    }

    /**
     * Decompresses the bytes into bits where each byte contains only one bit
     *
     * @param bytes an array of type byte which contains the bits in bytes
     * @param size  the number of bits which were originally the size of the bits before compression into bytes in java
     * @return an array of type byte which contains the bits in bytes where each byte contains only one bit
     */
    byte[] unCompressBits(byte[] bytes, int size) {
        byte[] bits = new byte[size];
        int index = 0;
        int byteIndex = 0;
        while (index < size) {
            byte b = bytes[byteIndex];
            if(b == REPLACEMENT_LINE) {
                b = LINE_FEED;
            }
            if(b == REPLACEMENT_CARRIAGE) {
                b = CARRIAGE_RETURN;
            }
            byteIndex++;
            String string = byteToString(b);
            int extraBits = (int) BITS_IN_BYTE - (size - index);
            for (int i = 0; i < BITS_IN_BYTE && index < size; i++) {
                if (extraBits > 0 && extraBits < BITS_IN_BYTE) {
                    extraBits--;
                    continue;
                }
                bits[index] = string.charAt(i) == '1' ? (byte) 1 : (byte) 0;
                index++;
            }
        }
        return bits;
    }

    private String byteToString(byte b) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < BITS_IN_BYTE; i++) {
            stringBuilder.append((b & 1));
            b = (byte) (b >> 1);
        }
        stringBuilder.reverse();
        return stringBuilder.toString();
    }


    private byte getByte(byte[] bits, int length, int index) {
        StringBuilder byteString = new StringBuilder();
        for (int i = index; i < BITS_IN_BYTE + index && i < length; i++) {
            byteString.append(bits[i]);
        }
        String string = byteString.toString();
        return Byte.parseByte(string, 2);
    }
}