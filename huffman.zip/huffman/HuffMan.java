package huffman;

import huffman.dataStructure.BinaryTree;
import huffman.dataStructure.Node;
import huffman.dataStructure.PriorityQueue;

import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

public class HuffMan {
    /**
     * takes a text and encodes it using the huffman tree and a priority queue
     *
     * @param text the text to encode
     * @return A content instance containing the encoded text and the huffman tree
     */
    public Content encode(String text) {
        BinaryTree binaryTree = makeBinaryTree(text);
        byte[] treeBits = binaryTree.getBytes();
        byte[] charsBits = binaryTree.getChars();
        byte[] dataBits = binaryTree.getData(text);
        return new Content(dataBits, treeBits, charsBits);
    }

    private BinaryTree makeBinaryTree(String text) {
        Map<Character, Integer> frequencies = getFrequencies(text);
        PriorityQueue priorityQueue = makePriorityQueue(frequencies);
        Node root = priorityQueue.peek();
        return new BinaryTree(root);
    }

    private PriorityQueue makePriorityQueue(Map<Character, Integer> frequencies) {
        PriorityQueue pq = new PriorityQueue(10);
        for (Map.Entry<Character, Integer> entry : frequencies.entrySet()) {
            Node node = new Node(entry.getKey(), entry.getValue());
            pq.add(node);
        }
        while (pq.size() >= 2) {
            Node right = pq.remove();
            Node left = pq.remove();
            int frequency = 0;
            if (left != null) {
                frequency = right.getFrequency() + left.getFrequency();
            }
            Node node = new Node(frequency, right, left);
            pq.add(node);
        }
        return pq;
    }

    /**
     * takes a content instance and decodes it back into text
     *
     * @param content the content instance to decode
     * @return the decoded text
     */
    public String decode(Content content) {
        byte[] tree = content.getTree();
        byte[] data = content.getData();
        byte[] chars = content.getChars();
        BinaryTree binaryTree = getBinaryTree(tree, chars);
        StringBuilder sb = new StringBuilder();
        for (byte bit : data) {
            if (bit == 0) {
                binaryTree.goLeft();
            } else if (bit == 1) {
                binaryTree.goRight();
            }
            if (binaryTree.isLeaf()) {
                Character character = binaryTree.getCharacter();
                sb.append(character);
                binaryTree.resetCurrent();
            }
        }
        return sb.toString();
    }

    private BinaryTree getBinaryTree(byte[] tree, byte[] chars) {
        Stack<Node> stack = new Stack<>();
        Node root = new Node(' ');
        stack.add(root);
        Node node = stack.peek();
        // 1 because skip root
        int treeIndex = 1;
        int charIndex = 0;
        while (treeIndex < tree.length && charIndex < chars.length) {
            if (tree[treeIndex] == 0) {
                node = addBranch(stack, node);
            } else if (tree[treeIndex] == 1) {
                node = addLeaf(chars[charIndex], stack, node);
                charIndex++;
            }
            treeIndex++;
        }
        return new BinaryTree(root);
    }

    private Node addLeaf(byte aChar, Stack<Node> stack, Node node) {
        Node leaf = new Node((char) aChar);
        if (!node.hasRight()) {
            node.setRight(leaf);
        } else if (!node.hasLeft()) {
            node.setLeft(leaf);
            while (node.isFull() && !stack.isEmpty()) {
                node = stack.pop();
            }
        }
        return node;
    }

    private Node addBranch(Stack<Node> stack, Node node) {
        Node branch = new Node(' ');
        if (!node.hasRight()) {
            node.setRight(branch);
        } else if (!node.hasLeft()) {
            node.setLeft(branch);
        }

        stack.add(branch);
        node = stack.peek();
        return node;
    }

    private Map<Character, Integer> getFrequencies(String text) {
        Map<Character, Integer> frequencies = new HashMap<>();
        char[] chars = text.toCharArray();
        for (char c : chars) {
            int frequency = frequencies.getOrDefault(c, 0);
            frequencies.put(c, frequency + 1);
        }
        return frequencies;
    }

}
