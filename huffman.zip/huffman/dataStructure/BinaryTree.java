package huffman.dataStructure;


import java.util.*;

public class BinaryTree {
    private final Node root;
    private Node current;
    private final byte BRANCH = 0;
    private final byte LEAF = 1;
    private final byte RIGHT = 1;
    private final byte LEFT = 0;


    public BinaryTree(Node root) {
        this.root = root;
        this.current = this.root;
    }

    /**
     * @return an array of type byte which contains a bit representation of the tree
     */
    public byte[] getBytes() {
        List<Byte> bytes = new ArrayList<>();
        getBytes(root, bytes);
        return toBytesArray(bytes);
    }

    private void getBytes(Node node, List<Byte> bytes) {
        if (!node.isLeaf()) {
            bytes.add(BRANCH);
        } else {
            bytes.add(LEAF);
        }
        if (node.hasRight()) {
            Node right = node.getRight();
            getBytes(right, bytes);
        }
        if (node.hasLeft()) {
            Node left = node.getLeft();
            getBytes(left, bytes);
        }
    }


    /**
     * @return an array of type byte which contains the characters of the tree
     */
    public byte[] getChars() {
        List<Byte> bytes = new ArrayList<>();
        getChars(root, bytes);
        return toBytesArray(bytes);
    }

    private void getChars(Node node, List<Byte> bytes) {
        if (node.isLeaf()) {
            bytes.add((byte) node.getCharacter());
        }
        if (node.hasRight()) {
            Node right = node.getRight();
            getChars(right, bytes);
        }
        if (node.hasLeft()) {
            Node left = node.getLeft();
            getChars(left, bytes);
        }
    }


    public byte[] getData(String text) {
        char[] chars = text.toCharArray();
        List<Byte> path = new ArrayList<>();
        for (char character : chars) {
            List<Byte> characterPath = getPath(character);
            Collections.reverse(characterPath);
            path.addAll(characterPath);
        }
        return toBytesArray(path);
    }

    private List<Byte> getPath(char c) {
        return findCharacter(c);
    }

    private List<Byte> findCharacter(char c) {
        List<Byte> bytes = new ArrayList<>();
        char character = findCharacter(root, c, bytes);
        if (character != c) {
            throw new IllegalArgumentException("Character not found");
        }
        return bytes;
    }

    private Character findCharacter(Node node, char c, List<Byte> bytes) {
        if (node.hasRight()) {
            Node right = node.getRight();
            Character character = findCharacter(right, c, bytes);
            if (character == c) {
                bytes.add(RIGHT);
                return c;
            }

        }
        if (node.hasLeft()) {
            Node left = node.getLeft();
            Character character = findCharacter(left, c, bytes);
            if (character == c) {
                bytes.add(LEFT);
                return c;
            }
        }
        return node.getCharacter();
    }


    @Override
    public String toString() {
        return root.toString();
    }

    public void goLeft() {
        if (current.hasLeft()) {
            current = current.getLeft();
        }
    }

    public void goRight() {
        if (current.hasRight()) {
            current = current.getRight();
        }
    }

    public boolean isLeaf() {
        return current.isLeaf();
    }

    public Character getCharacter() {
        return current.getCharacter();
    }

    public void resetCurrent() {
        current = root;
    }

    private byte[] toBytesArray(List<Byte> path) {
        byte[] bytes = new byte[path.size()];
        for (int index = 0; index < path.size(); index++) {
            bytes[index] = path.get(index);
        }
        return bytes;
    }
}
