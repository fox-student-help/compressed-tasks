package huffman.dataStructure;

public class Node implements Comparable<Node> {
    private final Character character;
    private final int frequency;

    public int getFrequency() {
        return frequency;
    }

    private Node left;
    private Node right;

    public boolean hasRight() {
        return right != null;
    }

    public boolean hasLeft() {
        return left != null;
    }

    public boolean isLeaf() {
        return !hasRight() && !hasLeft();
    }

    public Node getLeft() {
        return left;
    }

    public Node getRight() {
        return right;
    }

    public Node(int frequency, Node right, Node left) {
        this.frequency = frequency;
        this.left = left;
        this.right = right;
        character = 0;
    }

    public Node(Character character) {
        this.character = character;
        frequency = 0;
    }

    public boolean isFull() {
        return hasLeft() && hasRight();
    }

    public Node(Character character, int frequency) {
        this.character = character;
        this.frequency = frequency;
        left = null;
        right = null;
    }

    @Override
    public int hashCode() {
        int hashCode = 13;
        hashCode += 7 * frequency;
        hashCode *= 1e9 + 7;
        hashCode += 11 * character.hashCode();
        return hashCode;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Node)) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        Node node = (Node) obj;
        return node.character == character && node.frequency == frequency;
    }

    @Override
    public int compareTo(Node node) {
        if (node == null) {
            return frequency;
        }
        return frequency - node.frequency;
    }

    @Override
    public String toString() {
        return "{" +
                "\"character\":" + "\"" + character + "\"" +
                ", \"frequency\":" + frequency +
                ", \"left\":" + left +
                ", \"right\":" + right +
                "}";
    }

    public char getCharacter() {
        return character;
    }

    public void setLeft(Node node) {
        this.left = node;
    }

    public void setRight(Node node) {
        this.right = node;
    }


    protected Node clone() {
        Node node = new Node(character, frequency);
        if (hasLeft()) {
            node.left = left.clone();
        }
        if (hasRight()) {
            node.right = right.clone();
        }
        return node;
    }
}