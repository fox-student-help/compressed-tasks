package huffman.dataStructure;

public class PriorityQueue {
    private static final int FRONT = 1;
    private int size;
    private Node[] pq;
    private final int CHARACTERS = 28;
    private int max_size = CHARACTERS * 4 + 1;
    public PriorityQueue() {
        size = 0;
        pq = new Node[max_size];
        pq[0] = new Node(' ', -1);
    }
    public PriorityQueue(int size_multiplier) {
        size = 0;
        pq = new Node[max_size * size_multiplier];
        pq[0] = new Node(' ', -1);
    }


    public int size() {
        return size;
    }

    public void add(Node node) {
        if(size >= max_size / 2) {
            max_size *= 2;
            Node[] temp = new Node[max_size];
            System.arraycopy(pq, 0, temp, 0, pq.length);
            pq = temp;
        }
        pq[++size] = node;
        int current = size;
        while (pq[current].compareTo(pq[parent(current)]) < 0) {
            swap(current, parent(current));
            current = parent(current);
        }
    }

    private void swap(int current, int parent) {
        Node temp = pq[current];
        pq[current] = pq[parent];
        pq[parent] = temp;
    }

    private int parent(int position) {
        return position / 2;
    }

    private void heapify(int position) {
        if (isLeaf(position)) {
            return;
        }
        if(pq[leftChild(position)] == null) {
            return;
        }
        if(pq[rightChild(position)] == null) {
            return;
        }
        if (greaterThanChildren(position)) {
            if (leftLessThanRight(position)) {
                swap(position, leftChild(position));
                heapify(leftChild(position));
            } else {
                swap(position, rightChild(position));
                heapify(rightChild(position));
            }
        }
    }

    private boolean leftLessThanRight(int position) {
        return pq[leftChild(position)].compareTo(pq[rightChild(position)]) < 0;
    }

    private boolean greaterThanChildren(int position) {
        return pq[position].compareTo(pq[leftChild(position)]) > 0
                || pq[position].compareTo(pq[rightChild(position)]) > 0;
    }

    private int leftChild(int position) {
        return position * 2;
    }

    private int rightChild(int pos) {
        return 2 * pos + 1;
    }

    private boolean isLeaf(int position) {
        return position > (size / 2) && position <= size;
    }


    public Node remove() {
        Node popped = pq[FRONT];
        pq[FRONT] = pq[size--];
        heapify(FRONT);
        return popped.clone();
    }

    public Node peek() {
        return pq[FRONT].clone();
    }
}
