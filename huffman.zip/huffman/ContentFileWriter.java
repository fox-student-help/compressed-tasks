package huffman;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.nio.file.Paths;

class ContentFileWriter {
    /**
     * Writes the content instance to a file and writes extra data related to the size to make sure that the file is not corrupted.
     *
     * @param content The content instance to write.
     * @param uri     The uri of the file to write to.
     * @throws IOException If an IOException occurs.
     */
    public void write(Content content, String uri) throws IOException {
        Path path = Paths.get(uri);
        try (PrintWriter printWriter = new PrintWriter(new BufferedWriter(new FileWriter(path.toFile())))) {
            printWriter.print(content.toString());
        }
    }
}