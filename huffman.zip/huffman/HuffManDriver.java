package huffman;

import java.io.*;

public class HuffManDriver {
    public void encode(String input, String output) throws IOException {
        HuffMan huffMan = new HuffMan();
        String text = readFile(input);
        Content content = huffMan.encode(text);
        ContentFileWriter writer = new ContentFileWriter();
        writer.write(content, output);

    }

    private String readFile(String input) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(input))) {
            StringBuilder builder = new StringBuilder();
            String line;
            line = reader.readLine();
            builder.append(line);
            while ((line = reader.readLine()) != null) {
                builder.append("\n");
                builder.append(line);
            }
            return builder.toString();
        }
    }

    private void writeFile(String text, String uri) throws IOException {
        try (PrintWriter printWriter = new PrintWriter(new BufferedWriter(new FileWriter(uri)))) {
            printWriter.write(text);
        }
    }


    public void decode(String input, String output) throws IOException {
        HuffMan huffMan = new HuffMan();
        ContentFileReader reader = new ContentFileReader();
        Content content = reader.read(input);
        String text = huffMan.decode(content);
        writeFile(text, output);
    }
}
